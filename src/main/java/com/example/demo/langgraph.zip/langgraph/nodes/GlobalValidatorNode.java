package com.example.demo.langgraph.nodes;

// 기업공시작성기준 검증 노드
public class GlobalValidatorNode {
}
