package com.example.demo.langgraph.nodes;

// 검증 실패 후, 프롬프트 추가 및 재시도 회수 기록하는 노드
public class RetryAdjustNode {
}
